<button
    {{ $attributes->merge(['class' => 'flex items-center gap-2 justify-center bg-neutral/10 text-base text-sm font-medium border border-neutral/20 hover:bg-neutral/15 hover:border-neutral/30 py-2 px-4 rounded-md shadow-sm transition-all duration-200 cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 focus:outline-none focus:ring-2 focus:ring-neutral/20']) }}>
    @if (isset($type) && $type === 'submit')
        <div role="status" wire:loading>
            <svg aria-hidden="true" class="size-6 me-2 fill-background animate-spin" viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg">
                <path d="M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm0,19a8,8,0,1,1,8-8A8,8,0,0,1,12,20Z" opacity="0.25" />
                <path
                    d="M12,4a8,8,0,0,1,7.89,6.7A1.53,1.53,0,0,0,21.38,12h0a1.5,1.5,0,0,0,1.48-1.75,11,11,0,0,0-21.72,0A1.5,1.5,0,0,0,2.62,12h0a1.53,1.53,0,0,0,1.49-1.3A8,8,0,0,1,12,4Z" />
            </svg>
            <span class="sr-only">Loading...</span>
        </div>
        <div wire:loading.remove>
            {{ $slot }}
        </div>
    @else
        {{ $slot }}
    @endif
</button>
